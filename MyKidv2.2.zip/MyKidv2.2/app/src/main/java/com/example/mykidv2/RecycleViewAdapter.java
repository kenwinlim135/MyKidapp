package com.example.mykidv2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class RecycleViewAdapter extends RecyclerView.Adapter<RecycleViewAdapter.ActivityViewHolder> implements Filterable {
    private List<Activity> mActivity;
    private List<Activity> mActivityFull;
    private OnItemCLickListener listener;
    private ActivityViewModel activityViewModel;
    private LayoutInflater mInflater;

    class ActivityViewHolder extends RecyclerView.ViewHolder {
        private final TextView textViewActivityName;
        private final TextView textViewReporterName;
        private final TextView textViewDate;

        ActivityViewHolder(View itemView) {
            super(itemView);
            textViewActivityName = itemView.findViewById(R.id.activity); // your Activity Name ID
            textViewDate = itemView.findViewById(R.id.date); // your Activity date ID
            textViewReporterName = itemView.findViewById(R.id.rpt);// your Reporter name ID

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if(listener!= null && position!=RecyclerView.NO_POSITION){
                        listener.onItemClick(mActivity.get(position));
                    }
                }
            });
        }
    }

    public RecycleViewAdapter(Context context) {
        mInflater = LayoutInflater.from(context);

        // init the lists
        mActivity = new ArrayList<>();
        mActivityFull = new ArrayList<>();
    }
    public Activity getActivityPosition(int position){
        return mActivity.get(position);
    }
    public interface OnItemCLickListener{
        void onItemClick(Activity activity);
    }
    public void setOnItemClickListener(OnItemCLickListener listener){
        this.listener = listener;
    }
    @NonNull
    @Override
    public ActivityViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.recycleview_item, parent, false);
        return new ActivityViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ActivityViewHolder holder, int position) {
        Activity currentActivity = mActivity.get(position);

        holder.textViewActivityName.setText(String.valueOf(currentActivity.getActivity_name()));
        holder.textViewDate.setText(String.valueOf(currentActivity.getDate()));
        holder.textViewReporterName.setText(String.valueOf(currentActivity.getReporter_name()));
    }

    @Override
    public int getItemCount() {
        return mActivity.size();
    }

    public void setActivity(List<Activity> activity) {
        this.mActivity = activity;
        mActivityFull = new ArrayList<>(activity);
        notifyDataSetChanged();
    }

    @Override
    public Filter getFilter(){
        return activityFilter;
    }

    public Filter activityFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            List<Activity> filteredList = new ArrayList<>();

            if (constraint == null || constraint.length() == 0) {
                filteredList.addAll(mActivityFull);
            } else {
                String filterPattern = constraint.toString().toLowerCase().trim();

                for (Activity item : mActivityFull) {
                    if (item.getActivity_name().toLowerCase().contains(filterPattern)) {
                        filteredList.add(item);
                    }
                }
            }
            FilterResults results = new FilterResults();
            results.values = filteredList;
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            mActivity.clear();
            mActivity.addAll((List) results.values);
            notifyDataSetChanged();
        }
    };
}
