package com.example.mykidv2;
import android.app.SearchManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.inputmethod.EditorInfo;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    public static final int ADD_ACTIVITY_REQUEST_CODE = 1;
    public static final int EDIT_ACTIVITY_REQUEST = 2;
    private ActivityViewModel mActivityViewModel;
    private RecycleViewAdapter adapter;
    private List<Activity> mActivityList;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        adapter = new RecycleViewAdapter(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);

        mActivityViewModel = ViewModelProviders.of(this).get(ActivityViewModel.class);
        mActivityViewModel.getAllActivity().observe(this, new Observer<List<Activity>>() {
            @Override
            public void onChanged(List<Activity> activity) {
                adapter.setActivity(activity);
            }
        });

        adapter.setOnItemClickListener(new RecycleViewAdapter.OnItemCLickListener() {
            @Override
            public void onItemClick(Activity activity) {
                Intent intent = new Intent(MainActivity.this, AddEditActivity.class);
                intent.putExtra(AddEditActivity.EXTRA_ACTIVITY_ID,activity.getId());
                intent.putExtra(AddEditActivity.EXTRA_ACTIVITY_NAME,activity.getActivity_name());
                intent.putExtra(AddEditActivity.EXTRA_LOCATION,activity.getLocation());
                intent.putExtra(AddEditActivity.EXTRA_DATE_VAL,activity.getDate());
                intent.putExtra(AddEditActivity.EXTRA_TIME_VAL,activity.getTime());
                intent.putExtra(AddEditActivity.EXTRA_REPORTER_NAME,activity.getReporter_name());
                intent.putExtra(AddEditActivity.EXTRA_IMAGE,activity.getImage());
                startActivityForResult(intent, EDIT_ACTIVITY_REQUEST);
            }
        });
        ItemTouchHelper helper = new ItemTouchHelper(
                new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.RIGHT) {
                    @Override
                    public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                        return false;
                    }
                    @Override
                    public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                        int position = viewHolder.getAdapterPosition();
                        Activity activity = adapter.getActivityPosition(position);
                        androidx.appcompat.app.AlertDialog.Builder myAlertBuilder = new AlertDialog.Builder(MainActivity.this);
                        myAlertBuilder.setTitle("Confirmation");
                        myAlertBuilder.setMessage("Are you sure want to delete?");
                        myAlertBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(MainActivity.this, activity.getActivity_name()+ "Deleted ", Toast.LENGTH_LONG).show();
                                mActivityViewModel.delete(activity);
                            }
                        });

                        myAlertBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                recyclerView.setAdapter(adapter);
                            }
                        });
                        myAlertBuilder.show();
                    }

                });
        helper.attachToRecyclerView(recyclerView);
    }


    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_toolbar, menu);

        // Get the SearchView and set the searchable configuration
        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        SearchView searchView = (SearchView) menu.findItem(R.id.search).getActionView();
        // Assumes current activity is the searchable activity
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        searchView.setIconifiedByDefault(false); // Do not iconify the widget; expand it by default
        searchView.setImeOptions(EditorInfo.IME_ACTION_DONE);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }
            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            }
        });
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Change the map type based on the user's selection.
        switch (item.getItemId()) {
            case R.id.add_button:
                Intent intent = new Intent(this, AddEditActivity.class);
                startActivityForResult(intent, ADD_ACTIVITY_REQUEST_CODE);
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ADD_ACTIVITY_REQUEST_CODE && resultCode == RESULT_OK) { // Add your Add activity class before the REQUEST_CODE
            String activity_name = data.getStringExtra(AddEditActivity.EXTRA_ACTIVITY_NAME);
            String location = data.getStringExtra(AddEditActivity.EXTRA_LOCATION);
            String date = data.getStringExtra(AddEditActivity.EXTRA_DATE_VAL);
            String time = data.getStringExtra(AddEditActivity.EXTRA_TIME_VAL);
            String reporter_name = data.getStringExtra(AddEditActivity.EXTRA_REPORTER_NAME);
            byte[] image = data.getByteArrayExtra(AddEditActivity.EXTRA_IMAGE);

            Activity activity = new Activity(activity_name, location, date, time,reporter_name, image);
            mActivityViewModel.insert(activity);

            Toast.makeText(this, "Activity saved", Toast.LENGTH_SHORT).show();

        }
        else if (requestCode == EDIT_ACTIVITY_REQUEST && resultCode == RESULT_OK){
            int id = data.getIntExtra(AddEditActivity.EXTRA_ACTIVITY_ID,-1);

            if(id ==-1){
                Toast.makeText(this, "Activity can't be updated", Toast.LENGTH_SHORT).show();
                return;
            }
            String activity_name = data.getStringExtra(AddEditActivity.EXTRA_ACTIVITY_NAME);
            String location = data.getStringExtra(AddEditActivity.EXTRA_LOCATION);
            String date = data.getStringExtra(AddEditActivity.EXTRA_DATE_VAL);
            String time = data.getStringExtra(AddEditActivity.EXTRA_TIME_VAL);
            String reporter_name = data.getStringExtra(AddEditActivity.EXTRA_REPORTER_NAME);
            byte[] img = data.getByteArrayExtra(AddEditActivity.EXTRA_IMAGE);
            Activity activity = new Activity(activity_name,location,date, time, reporter_name, img);
            activity.setId(id);
            mActivityViewModel.update(activity);
            Toast.makeText(this, "Activity updated", Toast.LENGTH_SHORT).show();


        }
        else {
            Toast.makeText(this, "Activity not saved", Toast.LENGTH_SHORT).show();
        }
    }

}