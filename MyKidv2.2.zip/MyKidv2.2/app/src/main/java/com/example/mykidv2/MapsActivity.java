package com.example.mykidv2;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;


public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private double latitude;
    private double longitude;
    public String activity;
    public String address;
    public String date;
    public String time;
    public String reporter;
    public byte[] img;
    public static final String EXTRA_ACTIVITY_NAME =
            "com.example.mykidv2.EXTRA_ACTIVITY_NAME";
    public static final String EXTRA_LOCATION =
            "com.example.mykidv2.EXTRA_LOCATION";
    public static final String EXTRA_DATE_VAL =
            "com.example.mykidv2.EXTRA_DATE_VAL";
    public static final String EXTRA_TIME_VAL =
            "com.example.mykidv2.EXTRA_TIME";
    public static final String EXTRA_REPORTER_NAME =
            "com.example.mykidv2.EXTRA_REPORTER_NAME";
    public static final String EXTRA_IMAGE=
            "com.example.mykidv2.EXTRA_IMAGE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        Intent intent = getIntent();
        if (intent != null)
        {
            Bundle params = intent.getExtras();
            if  (params != null)
            {
                latitude = params.getDouble("lat");
                longitude = params.getDouble("long");
                activity = params.getString(EXTRA_ACTIVITY_NAME);
                address = params.getString(EXTRA_LOCATION);
                date = params.getString(EXTRA_DATE_VAL);
                time = params.getString(EXTRA_TIME_VAL);
                reporter = params.getString(EXTRA_REPORTER_NAME);
                try{

                    img = params.getByteArray(EXTRA_IMAGE);
                }
                catch  (Exception exception){}
            }
        }
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        SupportMapFragment mapFragment = SupportMapFragment.newInstance();
        getSupportFragmentManager().beginTransaction()
                .add(R.id.fragment_container, mapFragment).commit();
        mapFragment.getMapAsync(this);

    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        String displayMsg = activity;

        // Add a marker in Current Location and move the camera
        LatLng Location = new LatLng(latitude, longitude);
        mMap.addMarker(new MarkerOptions().position(Location).title(displayMsg));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Location));

    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.map_options, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Change the map type based on the user's selection.
        switch (item.getItemId()) {
            case android.R.id.home:
                saveData();
                return true;
            case R.id.normal_map:
                mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                return true;
            case R.id.hybrid_map:
                mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
                return true;
            case R.id.satellite_map:
                mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
                return true;
            case R.id.terrain_map:
                mMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
                return true;
            case R.id.submit_button:
                alertDialog();
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void alertDialog(){
        LinearLayout display = new LinearLayout(this);
        display.setOrientation(LinearLayout.VERTICAL);
        final TextView DisplayLocation = new TextView(this);
        //Set the current data inside the new variable
        DisplayLocation.setText("\t\t\t" + "Location:\t" + address);
        DisplayLocation.setTextSize(20);
        DisplayLocation.setTextColor(Color.BLACK);
        // add inside the output
        display.addView(DisplayLocation);
        androidx.appcompat.app.AlertDialog.Builder myAlertBuilder = new
                AlertDialog.Builder(MapsActivity.this);
        myAlertBuilder.setTitle("Confirmation");
        myAlertBuilder.setMessage("Confirm location?")
                .setView(display);

        myAlertBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                saveData();
            }
        });

        myAlertBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        myAlertBuilder.show();
    }

    public void saveData() {
        Intent data = new Intent();
        data.putExtra(EXTRA_ACTIVITY_NAME, reporter);
        data.putExtra(EXTRA_LOCATION, address);
        data.putExtra(EXTRA_DATE_VAL, date);
        data.putExtra(EXTRA_TIME_VAL, time);
        data.putExtra(EXTRA_REPORTER_NAME, reporter);
        data.putExtra(EXTRA_IMAGE, img);

        setResult(RESULT_OK, data);
        finish();
    }
}

