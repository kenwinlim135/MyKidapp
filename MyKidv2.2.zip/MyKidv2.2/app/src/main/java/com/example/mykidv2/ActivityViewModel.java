package com.example.mykidv2;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import java.util.List;

public class ActivityViewModel extends AndroidViewModel {
    private ActivityRepository repository;
    private LiveData<List<Activity>> allActivity;
    public ActivityViewModel(@NonNull Application application) {
        super(application);
        repository = new ActivityRepository(application);
        allActivity = repository.getAllActivity();
    }
    public void insert(Activity activity) {
        repository.insert(activity);
    }
    public void update(Activity activity) {
        repository.update(activity);
    }
    public void delete(Activity activity) {
        repository.delete(activity);
    }
    public LiveData<List<Activity>> getAllActivity() {
        return allActivity;
    }
}
