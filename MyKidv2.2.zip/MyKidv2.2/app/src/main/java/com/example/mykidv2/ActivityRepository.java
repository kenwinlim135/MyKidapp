package com.example.mykidv2;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;
public class ActivityRepository {
    private ActivityDao activityDao;
    private LiveData<List<Activity>> allActivity;
    public ActivityRepository(Application application) {
        ActivityRoomDatabase database = ActivityRoomDatabase.getInstance(application);
        activityDao = database.activityDao();
        allActivity= activityDao.getAllActivity();
    }
    public void insert(Activity activity) {
        new InsertActivityAsyncTask(activityDao).execute(activity);
    }
    public void update(Activity activity) {
        new UpdateActivityAsyncTask(activityDao).execute(activity);
    }
    public void delete(Activity activity) {
        new DeleteActivityAsyncTask(activityDao).execute(activity);
    }
    public LiveData<List<Activity>> getAllActivity() {
        return allActivity;
    }

    private static class InsertActivityAsyncTask extends AsyncTask<Activity, Void, Void> {
        private ActivityDao activityDao;
        private InsertActivityAsyncTask(ActivityDao activityDao) {
            this.activityDao = activityDao;
        }
        @Override
        protected Void doInBackground(Activity... activity) {
            activityDao.insert(activity[0]);
            return null;
        }
    }
    private static class UpdateActivityAsyncTask extends AsyncTask<Activity, Void, Void> {
        private ActivityDao activityDao;
        private UpdateActivityAsyncTask(ActivityDao activityDao) {
            this.activityDao = activityDao;
        }
        @Override
        protected Void doInBackground(Activity... activity) {
            activityDao.update(activity[0]);
            return null;
        }
    }
    private static class DeleteActivityAsyncTask extends AsyncTask<Activity, Void, Void> {
        private ActivityDao activityDao;
        private DeleteActivityAsyncTask(ActivityDao activityDao) {
            this.activityDao = activityDao;
        }
        @Override
        protected Void doInBackground(Activity... activity) {
            activityDao.delete(activity[0]);
            return null;
        }
    }

}