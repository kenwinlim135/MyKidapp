package com.example.mykidv2;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.DialogFragment;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

public class AddEditActivity extends AppCompatActivity implements FetchAddressTask.OnTaskCompleted {
    public static final int MAIN_ACTIVITY_REQUEST_CODE = 1;

    private static final int REQUEST_LOCATION_PERMISSION = 1;
    private Button button_location;
    private TextView mLocationTextView;
    private Location mLastLocation;
    private FusedLocationProviderClient mFusedLocationClient;
    private DataConverter dataConverter;

    public static final String EXTRA_ACTIVITY_ID =
            "com.example.mykidv2.EXTRA_ACTIVITY_ID";
    public static final String EXTRA_ACTIVITY_NAME =
            "com.example.mykidv2.EXTRA_ACTIVITY_NAME";
    public static final String EXTRA_LOCATION =
            "com.example.mykidv2.EXTRA_LOCATION";
    public static final String EXTRA_DATE_VAL =
            "com.example.mykidv2.EXTRA_DATE_VAL";
    public static final String EXTRA_TIME_VAL =
            "com.example.mykidv2.EXTRA_TIME";
    public static final String EXTRA_REPORTER_NAME =
            "com.example.mykidv2.EXTRA_REPORTER_NAME";
    public static final  String EXTRA_IMAGE =
            "com.example.mykidv2.EXTRA_IMAGE";

    private EditText activityView;
    private EditText location;
    private EditText dateTextView;
    private EditText timeTextView;
    private EditText reporterView;
    private ImageView imageView;
    private Bitmap bmpImage;

    private String activityName;
    private String locationAddress;
    private String date1;
    private String time1;
    private String reporterName;
    private Bitmap picture;

    private double latitude;
    private double longitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        // Set the references
        button_location = findViewById(R.id.location_button);
        activityView = findViewById(R.id.activity_name);
        mLocationTextView = findViewById(R.id.location);
        location = findViewById(R.id.location);
        dateTextView = findViewById(R.id.date_val);
        timeTextView = findViewById(R.id.time_val);
        reporterView = findViewById(R.id.reporter);
        imageView = findViewById(R.id.userImage);

        // Initialize the FusedLocationClient.
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(
                this);

        button_location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getLocation();
            }
        });

        Intent intent = getIntent();
        if(intent.hasExtra(EXTRA_ACTIVITY_ID)){
            setTitle("Edit Activity");
            activityView.setText(intent.getStringExtra(EXTRA_ACTIVITY_NAME));
            location.setText(intent.getStringExtra(EXTRA_LOCATION));
            dateTextView.setText(intent.getStringExtra(EXTRA_DATE_VAL));
            timeTextView.setText(intent.getStringExtra(EXTRA_TIME_VAL));
            reporterView.setText(intent.getStringExtra(EXTRA_REPORTER_NAME));
            try{
                picture = dataConverter.convertByteArray2Image(intent.getByteArrayExtra(EXTRA_IMAGE));
                imageView.setImageBitmap(picture);
                this.bmpImage = picture;
            }
            catch (Exception e){}
        }

        if (savedInstanceState != null) {
            activityName = savedInstanceState.getString("activity");
            locationAddress = savedInstanceState.getString("location");
            date1 = savedInstanceState.getString("date");
            time1 = savedInstanceState.getString("time");
            reporterName = savedInstanceState.getString("reporter");
            picture = savedInstanceState.getParcelable("picture");
            this.bmpImage = picture;

            activityView.setText(String.valueOf(activityName));
            location.setText(String.valueOf(locationAddress));
            dateTextView.setText(String.valueOf(date1));
            timeTextView.setText(String.valueOf(time1));
            reporterView.setText(String.valueOf(reporterName));
            imageView.setImageBitmap(this.bmpImage);
        }
//        backIcon.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(AddEditActivity.this, MainActivity.class);
//                startActivityForResult(intent, MAIN_ACTIVITY_REQUEST_CODE);
//
//            }
//        });

    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.add_activity_toolbar, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Change the map type based on the user's selection.
        switch (item.getItemId()) {
            case R.id.submit:
                alertDialog();
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void showDatePicker(View view) {
        DialogFragment newFragment = new DatePickerFragment();
        newFragment.setStyle(DialogFragment.STYLE_NO_FRAME, 0);
        newFragment.show(getSupportFragmentManager(), "datePicker");
    }

    public void processDatePickerResult(int year, int month, int day) {
        String month_string = Integer.toString(month+1);
        String day_string = Integer.toString(day);
        String year_string = Integer.toString(year);
        if (month_string.length() == 1) month_string = "0" + month_string;
        if (day_string.length() == 1) day_string = "0" + day_string;
        String dateMessage = (day_string +"/" + month_string + "/" + year_string);
        dateTextView.setText(dateMessage);
    }

    public void showTimePicker(View view) {
        DialogFragment newFragment = new TimePickerFragment();
        newFragment.show(getSupportFragmentManager(), "timePicker");
    }

    public void processTimePickerResult(int hour, int minute) {
        String hour_string = Integer.toString(hour);
        String minute_string = Integer.toString(minute);
        if (hour_string.length() == 1) hour_string = "0" + hour_string;
        if (minute_string.length() == 1) minute_string = "0" + minute_string;
        String timeMessage = (hour_string +":" + minute_string);
        timeTextView.setText(timeMessage);
    }

    // Can receive the image that taken by the camera into our program
    final int CAMERA_INTENT = 51;

    // Calling the camera inside our phone
    public void capturePicture(View view) {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if(intent.resolveActivity(getPackageManager()) != null){
            startActivityForResult(intent, CAMERA_INTENT);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case CAMERA_INTENT:
                //            if (requestCode == Activity.RESULT_OK){
                this.bmpImage = (Bitmap) data.getExtras().get("data"); //converting into bitmap


                //bitmap = bmpImage;
                if(bmpImage != null){
                    imageView.setImageBitmap(this.bmpImage); // put the bitmap into our image
                }else{
                    Toast.makeText(
                            this,
                            "Bitmap is NULL",
                            Toast.LENGTH_SHORT
                    ).show();
                }
                break;
        }
    }

    public void alertDialog(){
        String activityName = activityView.getText().toString();
        String lct = location.getText().toString();
        String date = dateTextView.getText().toString();
        String time = timeTextView.getText().toString();
        String rpt = reporterView.getText().toString();
        if (activityName.trim().isEmpty() || lct.trim().isEmpty() || date.trim().isEmpty() || time.trim().isEmpty() || rpt.trim().isEmpty()) {
            Toast.makeText(this, "Please insert all the field above", Toast.LENGTH_SHORT).show();
            return;
        }
        else if(date.trim().length() != 10) {
            Toast.makeText(this, "Please insert date", Toast.LENGTH_SHORT).show();
            return;
        }
        else if(time.trim().length() != 5) {
            Toast.makeText(this, "Please insert time", Toast.LENGTH_SHORT).show();
            return;
        }
        else {
            LinearLayout display = new LinearLayout(this);
            display.setOrientation(LinearLayout.VERTICAL);
            final TextView DisplayActivity = new TextView(this);
            final TextView DisplayLocation = new TextView(this);
            final TextView DisplayDate = new TextView(this);
            final TextView DisplayTime = new TextView(this);
            final TextView DisplayReporterName = new TextView(this);
            //Set the current data inside the new variable
            DisplayActivity.setText("\t\t\t" + "Activity:\t" + activityName);
            DisplayActivity.setTextSize(20);
            DisplayActivity.setTextColor(Color.BLACK);
            DisplayLocation.setText("\t\t\t" + "Location:\t" + lct);
            DisplayLocation.setTextSize(20);
            DisplayLocation.setTextColor(Color.BLACK);
            DisplayDate.setText("\t\t\t" + "Date:\t" + date);
            DisplayDate.setTextSize(20);
            DisplayDate.setTextColor(Color.BLACK);
            DisplayTime.setText("\t\t\t" + "Time:\t" + time);
            DisplayTime.setTextSize(20);
            DisplayTime.setTextColor(Color.BLACK);
            DisplayReporterName.setText("\t\t\t" + "Reported By:\t" + rpt);
            DisplayReporterName.setTextSize(20);
            DisplayReporterName.setTextColor(Color.BLACK);
            // add inside the output
            display.addView(DisplayActivity);
            display.addView(DisplayLocation);
            display.addView(DisplayDate);
            display.addView(DisplayTime);
            display.addView(DisplayReporterName);
            androidx.appcompat.app.AlertDialog.Builder myAlertBuilder = new
                    AlertDialog.Builder(AddEditActivity.this);
            myAlertBuilder.setTitle("Confirmation");
            myAlertBuilder.setMessage("Are you sure want to continue?")
                    .setView(display);

            myAlertBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    submitData();
                }
            });

            myAlertBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            myAlertBuilder.show();
        }

    }

    public void submitData() {
        String activityName = activityView.getText().toString();
        String lct = location.getText().toString();
        String date = dateTextView.getText().toString();
        String time = timeTextView.getText().toString();
        String rpt = reporterView.getText().toString();
        Intent data = new Intent();
        if (bmpImage != null) {
            byte[] img = dataConverter.convertImage2ByteArray(bmpImage);
            data.putExtra(EXTRA_ACTIVITY_NAME, activityName);
            data.putExtra(EXTRA_LOCATION, lct);
            data.putExtra(EXTRA_DATE_VAL, date);
            data.putExtra(EXTRA_TIME_VAL, time);
            data.putExtra(EXTRA_REPORTER_NAME, rpt);
            data.putExtra(EXTRA_IMAGE, img);
        }
        else {
            data.putExtra(EXTRA_ACTIVITY_NAME, activityName);
            data.putExtra(EXTRA_LOCATION, lct);
            data.putExtra(EXTRA_DATE_VAL, date);
            data.putExtra(EXTRA_TIME_VAL, time);
            data.putExtra(EXTRA_REPORTER_NAME, rpt);
        }

        int id = getIntent().getIntExtra(EXTRA_ACTIVITY_ID,-1);
        if(id != -1){
            data.putExtra(EXTRA_ACTIVITY_ID,id);
        }

        setResult(RESULT_OK, data);
        finish();
    }

    private void getLocation() {
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]
                            {Manifest.permission.ACCESS_FINE_LOCATION},
                    REQUEST_LOCATION_PERMISSION);
        } else {
            //Log.d("LOCATION", "getLocation: permissions granted");
            mFusedLocationClient.getLastLocation().addOnSuccessListener(new OnSuccessListener<Location>() {
                @Override
                public void onSuccess(Location location) {
                    if (location != null) {

                        mLastLocation = location;
                        latitude = mLastLocation.getLatitude();
                        longitude = mLastLocation.getLongitude();
                        new FetchAddressTask(AddEditActivity.this,
                                AddEditActivity.this).execute(location);
                    } else {
                        mLocationTextView.setText(R.string.no_location);
                    }
                }
            });
        }
        mLocationTextView.setText(getString(R.string.address_text,
                getString(R.string.loading),
                System.currentTimeMillis()));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_LOCATION_PERMISSION:
                // If the permission is granted, get the location,
                // otherwise, show a Toast
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    getLocation();
                } else {
                    Toast.makeText(this,
                            R.string.location_permission_denied,
                            Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }

    @Override
    public void onTaskCompleted(String result) {
        mLocationTextView.setText(result);

        //String temp = String.valueOf(latitude);
        //activityView.setText(temp);
        Intent intent = new Intent(AddEditActivity.this, MapsActivity.class);
        Bundle params = new Bundle();
        params.putDouble("lat", latitude);
        params.putDouble("long", longitude);
        params.putString(MapsActivity.EXTRA_ACTIVITY_NAME, activityView.getText().toString());
        params.putString(MapsActivity.EXTRA_LOCATION, result);
        params.putString(MapsActivity.EXTRA_DATE_VAL, dateTextView.getText().toString());
        params.putString(MapsActivity.EXTRA_TIME_VAL, timeTextView.getText().toString());
        params.putString(MapsActivity.EXTRA_REPORTER_NAME, reporterView.getText().toString());
        intent.putExtras(params);

        startActivity(intent);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        activityName = activityView.getText().toString();
        locationAddress = location.getText().toString();
        date1 = dateTextView.getText().toString();
        time1 = timeTextView.getText().toString();
        reporterName = reporterView.getText().toString();

        outState.putString("activity", activityName);
        outState.putString("location", locationAddress);
        outState.putString("date", date1);
        outState.putString("time", time1);
        outState.putString("reporter", reporterName);
        outState.putParcelable("picture", bmpImage);

    }
}