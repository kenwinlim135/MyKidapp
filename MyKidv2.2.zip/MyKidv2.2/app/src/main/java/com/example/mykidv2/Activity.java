package com.example.mykidv2;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;


@Entity(tableName = "activity_table")
public class Activity {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String activity_name;
    private String location;
    private String date;
    private String time;
    private String reporter_name;
    @ColumnInfo(typeAffinity = ColumnInfo.BLOB)
    private byte[] image;
    public Activity(String activity_name,
                    String location,
                    String date, String time,
                    String reporter_name,
                    byte[] image){

        this.activity_name = activity_name;
        this.location = location;
        this.date = date;
        this.time = time;
        this.reporter_name = reporter_name;
        this.image = image;
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getId() {
        return id;
    }
    public  byte[] getImage(){ return image;}
    public String getActivity_name() {
        return activity_name;
    }
    public String getLocation() {
        return location;
    }
    public String getDate() {
        return date;
    }
    public String getTime() {
        return time;
    }
    public String getReporter_name() {
        return reporter_name;
    }

}